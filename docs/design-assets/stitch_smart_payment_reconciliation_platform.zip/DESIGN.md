---
name: Tanner Blueprints
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#424752'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#727784'
  outline-variant: '#c2c6d4'
  surface-tint: '#015cb9'
  primary: '#00458d'
  on-primary: '#ffffff'
  primary-container: '#005cb9'
  on-primary-container: '#c6d8ff'
  inverse-primary: '#aac7ff'
  secondary: '#1341e5'
  on-secondary: '#ffffff'
  secondary-container: '#3a5efe'
  on-secondary-container: '#f4f3ff'
  tertiary: '#004b71'
  on-tertiary: '#ffffff'
  tertiary-container: '#1c638f'
  on-tertiary-container: '#b6dcff'
  error: '#BE123C'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e3ff'
  primary-fixed-dim: '#aac7ff'
  on-primary-fixed: '#001b3e'
  on-primary-fixed-variant: '#00458e'
  secondary-fixed: '#dee1ff'
  secondary-fixed-dim: '#bac3ff'
  on-secondary-fixed: '#001159'
  on-secondary-fixed-variant: '#0031c5'
  tertiary-fixed: '#cbe6ff'
  tertiary-fixed-dim: '#90cdff'
  on-tertiary-fixed: '#001e31'
  on-tertiary-fixed-variant: '#004b72'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
  midnight-blue: '#001E3D'
  royal-blue: '#005CB9'
  alice-blue: '#EEF3F9'
  slate-gray: '#6B7280'
  border-lavender: '#E2E8F0'
  success: '#16A34A'
  warning: '#D97706'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  mono-data:
    fontFamily: Courier Prime
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  sidebar-width: 260px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
  container-max: 1440px
---

## Brand & Style

This design system is engineered for the high-stakes environment of fintech and payment reconciliation. The aesthetic is **Corporate / Modern**, characterized by professional reliability, functional clarity, and extreme precision.

The brand personality is authoritative yet accessible, using a deep monochromatic blue base to establish trust and vibrant semantic accents to highlight critical data points. The visual language utilizes subtle layering and soft depth to organize complex financial information into digestible views, ensuring that users feel in control of large-scale reconciliation tasks.

**Design Principles:**
- **Clarity First:** Prioritize data legibility and functional hierarchy over decorative elements.
- **Structured Trust:** Use rigid alignment and consistent spacing to reflect institutional stability.
- **Status Awareness:** Leverage semantic colors consistently to indicate system health and transactional accuracy.

## Colors

The palette is anchored by **Midnight Blue** for primary navigation and deep headers, creating a sense of permanence. **Royal Blue** serves as the primary interactive color for CTAs and focus states.

**Functional Color Assignments:**
- **Primary:** Used for main action buttons and active navigation markers.
- **Secondary:** Reserved for highlighting real-time calculation changes or secondary indicators.
- **Backgrounds:** The interface uses `Ghost White (#F8FAFC)` for the main workspace and `Alice Blue (#EEF3F9)` for subtle container differentiation, such as sidebars or inactive panel sections.
- **Semantics:** Status colors (Green, Amber, Crimson) must always be paired with their low-opacity equivalents for backgrounds to ensure high-contrast legibility for data badges and alerts.

## Typography

This design system utilizes **Inter** for all UI elements to ensure maximum legibility across dense data environments. 

**Application Rules:**
- **Headlines:** Use Bold (700) weights for page titles to establish a strong entry point.
- **Numerical Data:** For transaction tables and financial values, use the `mono-data` role to ensure column alignment and easy comparison.
- **Labels:** Labels for status badges and table headers use Medium (500) or Semi-Bold (600) weights in a smaller font size to maintain hierarchy without clutter.
- **Contrast:** High-level headers on Midnight Blue backgrounds should always be pure white or very light Alice Blue.

## Layout & Spacing

The layout follows a **Fixed Grid** model for the main dashboard content, anchored by a persistent left sidebar.

**Layout Model:**
- **Sidebar:** A fixed 260px width container using the Midnight Blue background.
- **Dashboard Grid:** A 12-column grid with 24px gutters.
- **Breakpoints:**
    - **Mobile (<768px):** Sidebar collapses into a hamburger menu; margins reduce to 16px; data tables transition to card-based layouts.
    - **Tablet (768px - 1024px):** Sidebar may transition to an icon-only "rail" to maximize data workspace.
    - **Desktop (>1024px):** Full sidebar and expanded data views.

Spacing follows a 4px base unit (n * 4) to ensure mathematical harmony in dense UI components like data tables and calculation panels.

## Elevation & Depth

Visual hierarchy is conveyed through **Tonal Layers** and **Ambient Shadows**. This approach minimizes visual noise while clearly separating interactive surfaces from the background.

- **Level 0 (Background):** `Ghost White` or `Alice Blue`.
- **Level 1 (Cards/Panels):** Pure white surfaces with a subtle 1px border (`#E2E8F0`) and a very soft, diffused shadow (0px 4px 12px, 4% opacity black).
- **Level 2 (Modals/Popovers):** Pure white surfaces with a more pronounced shadow (0px 10px 25px, 8% opacity black) to indicate overlay.
- **Active States:** Interactive panels for real-time calculations utilize a subtle blue inner-glow or a slightly darker border (`#005CB9` at 20% opacity) when being edited.

## Shapes

The design system uses a **Rounded** shape language to soften the institutional feel of financial data.

- **Buttons & Inputs:** 0.5rem (8px) corner radius.
- **Cards & Dashboard Panels:** 1rem (16px) corner radius to create clear containment.
- **Badges & Status Tags:** Pill-shaped (fully rounded) to differentiate them from interactive buttons.
- **Data Selection:** Table row selection highlights should use a 4px radius on the highlight bar to maintain the rounded theme.

## Components

### Data Tables
- **Selection:** Use a primary blue vertical bar on the left edge of a row to indicate selection.
- **Zebra Striping:** Use `Alice Blue` at 40% opacity for even rows.
- **Headers:** Sticky headers with a 1px bottom border in `lavender`.

### Steppers
- **Visuals:** Use horizontal connectors for desktop and vertical for mobile.
- **States:** Completed steps use the `success` green; active steps use `royal-blue` with a pulsing ring; pending steps use `slate-gray`.

### Interactive Panels
- **Real-time Calculations:** Display calculated totals in a larger `headline-md` weight. Background should subtly shift to a very light blue tint when data is processing/recalculating.

### File Upload
- **Dropzone:** A dashed border in `slate-gray` that changes to `royal-blue` on drag-over. Include a progress bar using the primary color.

### Status Badges & Alerts
- **Success:** Sea Green text on Honeydew background.
- **Warning:** Chocolate text on Floral White background.
- **Error:** Crimson text on Lavender Blush background.
- **General Alerts:** Use a left-accent border (4px) in the semantic color to draw attention.