
  # Dashboard de conciliación de pagos

  This is a code bundle for Dashboard de conciliación de pagos. The original project is available at https://www.figma.com/design/4jLJjP0r80LeJ3QZq5Y9wB/Dashboard-de-conciliaci%C3%B3n-de-pagos.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  