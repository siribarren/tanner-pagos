import { useState, useCallback, useRef } from "react";
import {
  Upload,
  FileText,
  CheckCircle,
  XCircle,
  AlertTriangle,
  ChevronRight,
  Clock,
  History,
  LayoutDashboard,
  Settings,
  LogOut,
  User,
  Building2,
  CreditCard,
  ArrowUpRight,
  Minus,
  Plus,
  CheckCheck,
  RefreshCw,
  AlertCircle,
  ChevronDown,
  Search,
  Bell,
  SlidersHorizontal,
} from "lucide-react";

// ─── Types ─────────────────────────────────────────────────────────────────

interface Installment {
  id: number;
  number: number;
  dueDate: string;
  capital: number;
  interest: number;
  collection: number;
  status: "pendiente" | "vencida" | "pagada";
}

interface Reconciliation {
  id: string;
  date: string;
  client: string;
  rut: string;
  amount: number;
  installments: number;
  status: "exitosa" | "parcial" | "rechazada";
  bank: string;
}

// ─── Mock Data ─────────────────────────────────────────────────────────────

const INSTALLMENTS: Installment[] = [
  { id: 1, number: 4, dueDate: "2025-03-15", capital: 285000, interest: 18450, collection: 9500, status: "vencida" },
  { id: 2, number: 5, dueDate: "2025-04-15", capital: 285000, interest: 16200, collection: 9500, status: "vencida" },
  { id: 3, number: 6, dueDate: "2025-05-15", capital: 285000, interest: 14100, collection: 9500, status: "pendiente" },
  { id: 4, number: 7, dueDate: "2025-06-15", capital: 285000, interest: 12050, collection: 0, status: "pendiente" },
  { id: 5, number: 8, dueDate: "2025-07-15", capital: 285000, interest: 10200, collection: 0, status: "pendiente" },
  { id: 6, number: 9, dueDate: "2025-08-15", capital: 285000, interest: 8400, collection: 0, status: "pendiente" },
];

const HISTORY: Reconciliation[] = [
  { id: "REC-0041", date: "2025-06-28", client: "Carmen Rojas Vidal", rut: "12.345.678-9", amount: 621450, installments: 2, status: "exitosa", bank: "Banco de Chile" },
  { id: "REC-0040", date: "2025-06-25", client: "Pedro Soto Muñoz", rut: "9.876.543-2", amount: 310200, installments: 1, status: "parcial", bank: "Santander" },
  { id: "REC-0039", date: "2025-06-22", client: "Ana López Castro", rut: "15.432.198-7", amount: 892000, installments: 3, status: "exitosa", bank: "BCI" },
  { id: "REC-0038", date: "2025-06-20", client: "Jorge Martínez F.", rut: "11.222.333-4", amount: 285000, installments: 1, status: "rechazada", bank: "Scotiabank" },
  { id: "REC-0037", date: "2025-06-18", client: "Lucía Fernández G.", rut: "14.567.890-K", amount: 1140000, installments: 4, status: "exitosa", bank: "Banco Estado" },
];

// ─── Helpers ────────────────────────────────────────────────────────────────

const fmt = (n: number) =>
  new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 }).format(n);

const fmtDate = (d: string) =>
  new Date(d + "T12:00:00").toLocaleDateString("es-CL", { day: "2-digit", month: "short", year: "numeric" });

// ─── Sub-components ─────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: "pendiente" | "vencida" | "pagada" }) {
  const map = {
    pendiente: "bg-blue-50 text-blue-700 border-blue-200",
    vencida: "bg-rose-50 text-rose-700 border-rose-200",
    pagada: "bg-emerald-50 text-emerald-700 border-emerald-200",
  };
  const labels = { pendiente: "Pendiente", vencida: "Vencida", pagada: "Pagada" };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium border ${map[status]}`}>
      {labels[status]}
    </span>
  );
}

function RecStatusBadge({ status }: { status: "exitosa" | "parcial" | "rechazada" }) {
  const map = {
    exitosa: "bg-emerald-50 text-emerald-700 border-emerald-200",
    parcial: "bg-amber-50 text-amber-700 border-amber-200",
    rechazada: "bg-rose-50 text-rose-700 border-rose-200",
  };
  const labels = { exitosa: "Exitosa", parcial: "Parcial", rechazada: "Rechazada" };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium border ${map[status]}`}>
      {labels[status]}
    </span>
  );
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function App() {
  const [activeTab, setActiveTab] = useState<"upload" | "history">("upload");
  const [isDragging, setIsDragging] = useState(false);
  const [fileUploaded, setFileUploaded] = useState(false);
  const [fileName, setFileName] = useState("");
  const [selectedIds, setSelectedIds] = useState<number[]>([1, 2]);
  const [isReconciling, setIsReconciling] = useState(false);
  const [reconciled, setReconciled] = useState(false);
  const [expandedTimeline, setExpandedTimeline] = useState<string | null>("REC-0041");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Simulated transferred amount (from the uploaded voucher)
  const transferredAmount = 621450;

  const selectedInstallments = INSTALLMENTS.filter((i) => selectedIds.includes(i.id));
  const calculatedAmount = selectedInstallments.reduce(
    (acc, i) => acc + i.capital + i.interest + i.collection,
    0
  );
  const difference = transferredAmount - calculatedAmount;
  const tolerance = Math.abs(difference) <= 1000;
  const isOk = Math.abs(difference) <= 100;

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback(() => setIsDragging(false), []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      setFileName(file.name);
      setFileUploaded(true);
    }
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      setFileUploaded(true);
    }
  };

  const toggleInstallment = (id: number) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const toggleAll = () => {
    if (selectedIds.length === INSTALLMENTS.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(INSTALLMENTS.map((i) => i.id));
    }
  };

  const handleReconcile = () => {
    setIsReconciling(true);
    setTimeout(() => {
      setIsReconciling(false);
      setReconciled(true);
    }, 1800);
  };

  const handleReset = () => {
    setReconciled(false);
    setFileUploaded(false);
    setFileName("");
    setSelectedIds([1, 2]);
  };

  return (
    <div
      className="min-h-screen flex"
      style={{ fontFamily: "'Inter', sans-serif", background: "var(--background)" }}
    >
      {/* ── Sidebar ─────────────────────────────────────────── */}
      <aside className="w-56 flex-shrink-0 bg-[#1D2B4E] flex flex-col">
        {/* Logo */}
        <div className="px-5 pt-6 pb-5 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-[#2563EB] flex items-center justify-center">
              <CreditCard size={14} className="text-white" />
            </div>
            <div>
              <p className="text-white text-[13px] font-semibold leading-tight">ReconcilIA</p>
              <p className="text-white/40 text-[10px] leading-tight">Cobranzas Pro</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {[
            { icon: LayoutDashboard, label: "Dashboard", id: "upload" as const },
            { icon: History, label: "Historial", id: "history" as const },
          ].map(({ icon: Icon, label, id }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] font-medium transition-all ${
                activeTab === id
                  ? "bg-white/10 text-white"
                  : "text-white/50 hover:text-white/80 hover:bg-white/5"
              }`}
            >
              <Icon size={15} />
              {label}
            </button>
          ))}

          <div className="pt-4 pb-1">
            <p className="px-3 text-[10px] font-semibold text-white/25 uppercase tracking-widest">Configuración</p>
          </div>

          {[
            { icon: Settings, label: "Parámetros" },
            { icon: User, label: "Mi cuenta" },
          ].map(({ icon: Icon, label }) => (
            <button
              key={label}
              className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] text-white/40 hover:text-white/70 hover:bg-white/5 transition-all"
            >
              <Icon size={15} />
              {label}
            </button>
          ))}
        </nav>

        {/* User footer */}
        <div className="px-4 py-4 border-t border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-full bg-[#2563EB]/30 flex items-center justify-center text-[11px] font-semibold text-[#93C5FD]">
              MV
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white text-[12px] font-medium truncate">María Vargas</p>
              <p className="text-white/35 text-[10px] truncate">Operadora</p>
            </div>
            <button className="text-white/30 hover:text-white/60 transition-colors">
              <LogOut size={13} />
            </button>
          </div>
        </div>
      </aside>

      {/* ── Main ────────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="h-12 bg-card border-b border-border flex items-center justify-between px-6 flex-shrink-0">
          <div className="flex items-center gap-2 text-[12px] text-muted-foreground">
            <span>Dashboard</span>
            <ChevronRight size={12} />
            <span className="text-foreground font-medium">
              {activeTab === "upload" ? "Carga de Pago" : "Historial de Conciliaciones"}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-muted/60 rounded-lg px-3 py-1.5">
              <Search size={12} className="text-muted-foreground" />
              <input
                placeholder="Buscar por RUT o cliente..."
                className="bg-transparent text-[12px] outline-none w-44 placeholder:text-muted-foreground/60"
              />
            </div>
            <button className="relative text-muted-foreground hover:text-foreground transition-colors">
              <Bell size={16} />
              <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-rose-500 rounded-full" />
            </button>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-auto p-6">
          {activeTab === "upload" ? (
            <UploadView
              isDragging={isDragging}
              fileUploaded={fileUploaded}
              fileName={fileName}
              fileInputRef={fileInputRef}
              selectedIds={selectedIds}
              calculatedAmount={calculatedAmount}
              transferredAmount={transferredAmount}
              difference={difference}
              tolerance={tolerance}
              isOk={isOk}
              isReconciling={isReconciling}
              reconciled={reconciled}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onFileChange={handleFileChange}
              onToggle={toggleInstallment}
              onToggleAll={toggleAll}
              onReconcile={handleReconcile}
              onReset={handleReset}
            />
          ) : (
            <HistoryView
              history={HISTORY}
              expandedTimeline={expandedTimeline}
              setExpandedTimeline={setExpandedTimeline}
            />
          )}
        </main>
      </div>
    </div>
  );
}

// ─── Upload View ─────────────────────────────────────────────────────────────

interface UploadViewProps {
  isDragging: boolean;
  fileUploaded: boolean;
  fileName: string;
  fileInputRef: React.RefObject<HTMLInputElement>;
  selectedIds: number[];
  calculatedAmount: number;
  transferredAmount: number;
  difference: number;
  tolerance: boolean;
  isOk: boolean;
  isReconciling: boolean;
  reconciled: boolean;
  onDragOver: (e: React.DragEvent) => void;
  onDragLeave: () => void;
  onDrop: (e: React.DragEvent) => void;
  onFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onToggle: (id: number) => void;
  onToggleAll: () => void;
  onReconcile: () => void;
  onReset: () => void;
}

function UploadView({
  isDragging, fileUploaded, fileName, fileInputRef,
  selectedIds, calculatedAmount, transferredAmount, difference,
  tolerance, isOk, isReconciling, reconciled,
  onDragOver, onDragLeave, onDrop, onFileChange,
  onToggle, onToggleAll, onReconcile, onReset,
}: UploadViewProps) {

  if (reconciled) {
    return <ReconciliationSuccess onReset={onReset} />;
  }

  return (
    <div className="grid grid-cols-[1fr_300px] gap-5 items-start">
      {/* Left column */}
      <div className="space-y-5 min-w-0">
        {/* Upload + auto-fill */}
        <div className="grid grid-cols-2 gap-5">
          {/* Drop zone */}
          <div className="bg-card rounded-xl border border-border p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-[13px] font-semibold text-foreground">Comprobante de pago</h2>
              {fileUploaded && (
                <span className="flex items-center gap-1 text-[11px] text-emerald-600 font-medium">
                  <CheckCircle size={11} />
                  Cargado
                </span>
              )}
            </div>

            {!fileUploaded ? (
              <div
                onDragOver={onDragOver}
                onDragLeave={onDragLeave}
                onDrop={onDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center gap-3 cursor-pointer transition-all ${
                  isDragging
                    ? "border-[#2563EB] bg-blue-50"
                    : "border-border hover:border-[#2563EB]/50 hover:bg-muted/40"
                }`}
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${isDragging ? "bg-[#2563EB] text-white" : "bg-muted text-muted-foreground"}`}>
                  <Upload size={18} />
                </div>
                <div className="text-center">
                  <p className="text-[12px] font-medium text-foreground">Arrastra tu comprobante aquí</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">PDF, JPG, PNG — máx. 10 MB</p>
                </div>
                <button className="text-[11px] text-[#2563EB] font-medium px-3 py-1.5 border border-[#2563EB]/30 rounded-lg hover:bg-blue-50 transition-colors">
                  Seleccionar archivo
                </button>
              </div>
            ) : (
              <div className="border border-border rounded-lg overflow-hidden">
                {/* Simulated preview */}
                <div className="bg-gradient-to-b from-slate-50 to-slate-100 p-4 border-b border-border">
                  <div className="bg-white rounded-md shadow-sm p-3 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Building2 size={14} className="text-slate-400" />
                        <span className="text-[11px] font-semibold text-slate-700">Banco de Chile</span>
                      </div>
                      <span className="text-[10px] text-slate-400">Comprobante N° 84920341</span>
                    </div>
                    <div className="border-t border-slate-100 pt-2 space-y-1">
                      <div className="flex justify-between">
                        <span className="text-[10px] text-slate-500">Monto</span>
                        <span className="text-[11px] font-semibold text-slate-800" style={{ fontFamily: "'DM Mono', monospace" }}>$621.450</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[10px] text-slate-500">Fecha</span>
                        <span className="text-[10px] text-slate-600" style={{ fontFamily: "'DM Mono', monospace" }}>28/06/2025 14:32</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[10px] text-slate-500">Origen</span>
                        <span className="text-[10px] text-slate-600">12.345.678-9</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 px-3 py-2 bg-card">
                  <FileText size={12} className="text-muted-foreground" />
                  <span className="text-[11px] text-muted-foreground truncate flex-1">{fileName || "comprobante_junio.pdf"}</span>
                  <button
                    onClick={() => { /* reset */ }}
                    className="text-[11px] text-[#2563EB] hover:underline"
                  >
                    Cambiar
                  </button>
                </div>
              </div>
            )}
            <input ref={fileInputRef} type="file" accept=".pdf,.jpg,.png" className="hidden" onChange={onFileChange} />
          </div>

          {/* Auto-filled fields */}
          <div className="bg-card rounded-xl border border-border p-5">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-[13px] font-semibold text-foreground">Datos extraídos</h2>
              {fileUploaded && (
                <span className="text-[10px] text-[#2563EB] font-medium bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
                  Auto-completado
                </span>
              )}
            </div>

            <div className="space-y-3">
              {[
                { label: "RUT Pagador", value: fileUploaded ? "12.345.678-9" : "—", mono: true },
                { label: "Monto transferido", value: fileUploaded ? "$621.450" : "—", mono: true, highlight: true },
                { label: "Fecha de pago", value: fileUploaded ? "28 jun 2025, 14:32" : "—", mono: true },
                { label: "Banco origen", value: fileUploaded ? "Banco de Chile" : "—", mono: false },
                { label: "N° comprobante", value: fileUploaded ? "84920341" : "—", mono: true },
              ].map(({ label, value, mono, highlight }) => (
                <div key={label} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <span className="text-[11px] text-muted-foreground">{label}</span>
                  <span
                    className={`text-[12px] font-medium ${highlight ? "text-[#2563EB]" : "text-foreground"} ${!fileUploaded ? "text-muted-foreground" : ""}`}
                    style={mono ? { fontFamily: "'DM Mono', monospace" } : {}}
                  >
                    {value}
                  </span>
                </div>
              ))}
            </div>

            {!fileUploaded && (
              <p className="text-[11px] text-muted-foreground/60 text-center mt-4 italic">
                Sube un comprobante para extraer datos automáticamente
              </p>
            )}
          </div>
        </div>

        {/* Client identification card */}
        {fileUploaded && (
          <div className="bg-card rounded-xl border border-border p-5">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Cliente identificado</span>
                  <CheckCircle size={11} className="text-emerald-500" />
                </div>
                <h3 className="text-[15px] font-semibold text-foreground">Carmen Rojas Vidal</h3>
              </div>
              <span className="text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-1 rounded-lg">
                Al día (parcial)
              </span>
            </div>

            <div className="mt-4 grid grid-cols-4 gap-4">
              {[
                { label: "RUT", value: "12.345.678-9", mono: true },
                { label: "N° Crédito", value: "CR-2024-0187", mono: true },
                { label: "Deuda total", value: "$3.240.900", mono: true },
                { label: "Cuotas vencidas", value: "2 de 12", mono: false },
              ].map(({ label, value, mono }) => (
                <div key={label} className="bg-muted/40 rounded-lg px-3 py-2.5">
                  <p className="text-[10px] text-muted-foreground mb-1">{label}</p>
                  <p
                    className="text-[12px] font-semibold text-foreground"
                    style={mono ? { fontFamily: "'DM Mono', monospace" } : {}}
                  >
                    {value}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Installments table */}
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-border">
            <h2 className="text-[13px] font-semibold text-foreground">Cuotas pendientes</h2>
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-muted-foreground">{selectedIds.length} seleccionadas</span>
              <button className="flex items-center gap-1.5 text-[11px] text-muted-foreground hover:text-foreground px-2.5 py-1.5 rounded-lg border border-border hover:bg-muted/40 transition-colors">
                <SlidersHorizontal size={11} />
                Filtrar
              </button>
            </div>
          </div>

          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="px-4 py-2.5 w-8">
                  <input
                    type="checkbox"
                    checked={selectedIds.length === INSTALLMENTS.length}
                    onChange={onToggleAll}
                    className="w-3.5 h-3.5 accent-[#2563EB] cursor-pointer"
                  />
                </th>
                {["N° Cuota", "Vencimiento", "Capital", "Intereses", "Gas. Cobranza", "Total", "Estado"].map((h) => (
                  <th key={h} className="px-4 py-2.5 text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {INSTALLMENTS.map((inst) => {
                const total = inst.capital + inst.interest + inst.collection;
                const selected = selectedIds.includes(inst.id);
                return (
                  <tr
                    key={inst.id}
                    onClick={() => onToggle(inst.id)}
                    className={`border-b border-border last:border-0 cursor-pointer transition-colors ${
                      selected ? "bg-blue-50/50" : "hover:bg-muted/20"
                    }`}
                  >
                    <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                      <input
                        type="checkbox"
                        checked={selected}
                        onChange={() => onToggle(inst.id)}
                        className="w-3.5 h-3.5 accent-[#2563EB] cursor-pointer"
                      />
                    </td>
                    <td className="px-4 py-3 text-[12px] font-medium text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                      {inst.number.toString().padStart(2, "0")}
                    </td>
                    <td className="px-4 py-3 text-[12px] text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                      {fmtDate(inst.dueDate)}
                    </td>
                    <td className="px-4 py-3 text-[12px] text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                      {fmt(inst.capital)}
                    </td>
                    <td className="px-4 py-3 text-[12px] text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                      {fmt(inst.interest)}
                    </td>
                    <td className="px-4 py-3 text-[12px] text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                      {inst.collection > 0 ? fmt(inst.collection) : <span className="text-muted-foreground">—</span>}
                    </td>
                    <td className="px-4 py-3 text-[12px] font-semibold text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                      {fmt(total)}
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={inst.status} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ── Right panel: Calculation engine ─────────────── */}
      <div className="space-y-4 sticky top-0">
        {/* Calc engine */}
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <div className="px-4 py-3.5 border-b border-border flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-[#2563EB] animate-pulse" />
            <h2 className="text-[12px] font-semibold text-foreground">Motor de cálculo</h2>
          </div>

          <div className="p-4 space-y-3">
            {/* Transferred */}
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-muted-foreground">Monto transferido</span>
              <span className="text-[13px] font-semibold text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                {fmt(transferredAmount)}
              </span>
            </div>

            {/* Calculated */}
            <div className="flex items-center justify-between">
              <span className="text-[11px] text-muted-foreground">Monto calculado</span>
              <span className="text-[13px] font-semibold text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                {fmt(calculatedAmount)}
              </span>
            </div>

            {/* Divider + difference */}
            <div className="border-t border-border pt-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-foreground">Diferencia</span>
                <div className="flex items-center gap-1.5">
                  {difference > 0 ? (
                    <Plus size={11} className={isOk ? "text-emerald-500" : tolerance ? "text-amber-500" : "text-rose-500"} />
                  ) : difference < 0 ? (
                    <Minus size={11} className="text-rose-500" />
                  ) : null}
                  <span
                    className={`text-[13px] font-bold ${
                      isOk ? "text-emerald-600" : tolerance ? "text-amber-600" : "text-rose-600"
                    }`}
                    style={{ fontFamily: "'DM Mono', monospace" }}
                  >
                    {fmt(Math.abs(difference))}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Breakdown */}
          <div className="border-t border-border bg-muted/20 px-4 py-3 space-y-2">
            <p className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground mb-2">Desglose</p>
            {[
              { label: "Capital total", value: selectedIds.reduce((a, id) => a + (INSTALLMENTS.find(i => i.id === id)?.capital ?? 0), 0) },
              { label: "Intereses", value: selectedIds.reduce((a, id) => a + (INSTALLMENTS.find(i => i.id === id)?.interest ?? 0), 0) },
              { label: "Gastos de cobranza", value: selectedIds.reduce((a, id) => a + (INSTALLMENTS.find(i => i.id === id)?.collection ?? 0), 0) },
            ].map(({ label, value }) => (
              <div key={label} className="flex items-center justify-between">
                <span className="text-[11px] text-muted-foreground">{label}</span>
                <span className="text-[11px] text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                  {fmt(value)}
                </span>
              </div>
            ))}
          </div>

          {/* Status indicator */}
          <div className={`px-4 py-3 flex items-start gap-2.5 border-t ${isOk ? "bg-emerald-50 border-emerald-100" : tolerance ? "bg-amber-50 border-amber-100" : "bg-rose-50 border-rose-100"}`}>
            {isOk ? (
              <CheckCircle size={14} className="text-emerald-600 mt-0.5 flex-shrink-0" />
            ) : tolerance ? (
              <AlertTriangle size={14} className="text-amber-600 mt-0.5 flex-shrink-0" />
            ) : (
              <XCircle size={14} className="text-rose-600 mt-0.5 flex-shrink-0" />
            )}
            <div>
              <p className={`text-[11px] font-semibold ${isOk ? "text-emerald-700" : tolerance ? "text-amber-700" : "text-rose-700"}`}>
                {isOk ? "Montos coinciden" : tolerance ? "Diferencia dentro de tolerancia" : "Monto no coincide con cuotas seleccionadas"}
              </p>
              <p className={`text-[10px] mt-0.5 ${isOk ? "text-emerald-600" : tolerance ? "text-amber-600" : "text-rose-600"}`}>
                {isOk
                  ? "El pago cubre exactamente las cuotas seleccionadas."
                  : tolerance
                  ? "La diferencia es ≤ $1.000. Puede proceder."
                  : "Revise la selección de cuotas o ajuste el monto."}
              </p>
            </div>
          </div>
        </div>

        {/* Alerts */}
        {fileUploaded && selectedIds.length === 0 && (
          <div className="flex items-start gap-2.5 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3">
            <AlertCircle size={14} className="text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-[11px] text-amber-700">Debe seleccionar al menos una cuota para conciliar.</p>
          </div>
        )}

        {/* Action buttons */}
        <div className="space-y-2">
          <button
            onClick={onReconcile}
            disabled={!fileUploaded || selectedIds.length === 0 || isReconciling}
            className="w-full flex items-center justify-center gap-2 bg-[#1D2B4E] hover:bg-[#162240] disabled:opacity-40 disabled:cursor-not-allowed text-white text-[13px] font-semibold py-3 rounded-xl transition-colors"
          >
            {isReconciling ? (
              <>
                <RefreshCw size={14} className="animate-spin" />
                Procesando...
              </>
            ) : (
              <>
                <CheckCheck size={14} />
                Conciliar pago
              </>
            )}
          </button>

          <button
            disabled={!fileUploaded || selectedIds.length === 0}
            className="w-full flex items-center justify-center gap-2 bg-card hover:bg-muted/50 disabled:opacity-40 disabled:cursor-not-allowed text-foreground text-[13px] font-medium py-2.5 rounded-xl border border-border transition-colors"
          >
            <SlidersHorizontal size={13} />
            Ajustar cuotas
          </button>
        </div>

        {/* Info */}
        <p className="text-[10px] text-muted-foreground text-center leading-relaxed px-2">
          Al conciliar, el pago quedará registrado y las cuotas seleccionadas cambiarán su estado a <strong>Pagada</strong>.
        </p>
      </div>
    </div>
  );
}

// ─── Reconciliation Success ───────────────────────────────────────────────────

function ReconciliationSuccess({ onReset }: { onReset: () => void }) {
  const steps = [
    { label: "Comprobante recibido", time: "14:32:01", done: true },
    { label: "Datos extraídos con OCR", time: "14:32:03", done: true },
    { label: "Cliente identificado", time: "14:32:04", done: true },
    { label: "Cuotas seleccionadas (2)", time: "14:32:04", done: true },
    { label: "Montos validados", time: "14:32:05", done: true },
    { label: "Conciliación registrada", time: "14:32:06", done: true },
  ];

  return (
    <div className="max-w-2xl mx-auto pt-8">
      <div className="bg-card rounded-2xl border border-emerald-200 overflow-hidden shadow-sm">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 to-emerald-500 px-8 py-8 text-center">
          <div className="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={28} className="text-white" />
          </div>
          <h2 className="text-white text-[20px] font-bold">Conciliación exitosa</h2>
          <p className="text-emerald-100 text-[13px] mt-1">REC-0042 · 28 jun 2025, 14:32</p>
        </div>

        {/* Summary */}
        <div className="grid grid-cols-3 divide-x divide-border border-b border-border">
          {[
            { label: "Monto conciliado", value: "$621.450", mono: true },
            { label: "Cuotas saldadas", value: "2 cuotas", mono: false },
            { label: "Cliente", value: "C. Rojas Vidal", mono: false },
          ].map(({ label, value, mono }) => (
            <div key={label} className="px-6 py-4 text-center">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-1">{label}</p>
              <p
                className="text-[14px] font-semibold text-foreground"
                style={mono ? { fontFamily: "'DM Mono', monospace" } : {}}
              >
                {value}
              </p>
            </div>
          ))}
        </div>

        {/* Timeline */}
        <div className="px-8 py-6">
          <h3 className="text-[12px] font-semibold text-muted-foreground uppercase tracking-widest mb-4">
            Trazabilidad del pago
          </h3>
          <div className="relative">
            <div className="absolute left-[7px] top-2 bottom-2 w-px bg-emerald-200" />
            <div className="space-y-3.5">
              {steps.map((step, i) => (
                <div key={i} className="flex items-center gap-3.5">
                  <div className="w-3.5 h-3.5 rounded-full bg-emerald-500 flex-shrink-0 z-10 flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-white" />
                  </div>
                  <div className="flex items-center justify-between flex-1">
                    <span className="text-[12px] text-foreground font-medium">{step.label}</span>
                    <span className="text-[11px] text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                      {step.time}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="px-8 pb-6 flex gap-3">
          <button
            onClick={onReset}
            className="flex-1 bg-[#1D2B4E] hover:bg-[#162240] text-white text-[13px] font-semibold py-2.5 rounded-xl transition-colors"
          >
            Nuevo pago
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 border border-border rounded-xl text-[13px] text-foreground hover:bg-muted/50 transition-colors">
            <ArrowUpRight size={13} />
            Ver historial
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── History View ─────────────────────────────────────────────────────────────

function HistoryView({
  history,
  expandedTimeline,
  setExpandedTimeline,
}: {
  history: Reconciliation[];
  expandedTimeline: string | null;
  setExpandedTimeline: (id: string | null) => void;
}) {
  const timelineSteps: Record<string, string[]> = {
    "REC-0041": ["Comprobante recibido · 14:32:01", "OCR completado · 14:32:03", "Cliente identificado · 14:32:04", "2 cuotas seleccionadas · 14:32:04", "Conciliación exitosa · 14:32:06"],
    "REC-0040": ["Comprobante recibido · 11:14:22", "OCR completado · 11:14:24", "Cliente identificado · 11:14:25", "Diferencia $310 detectada · 11:14:25", "Conciliación parcial · 11:14:30"],
    "REC-0039": ["Comprobante recibido · 09:05:11", "OCR completado · 09:05:13", "Cliente identificado · 09:05:14", "3 cuotas seleccionadas · 09:05:14", "Conciliación exitosa · 09:05:16"],
    "REC-0038": ["Comprobante recibido · 16:45:00", "OCR completado · 16:45:02", "Cliente no encontrado · 16:45:03", "Conciliación rechazada · 16:45:03"],
    "REC-0037": ["Comprobante recibido · 10:22:44", "OCR completado · 10:22:46", "Cliente identificado · 10:22:47", "4 cuotas seleccionadas · 10:22:47", "Conciliación exitosa · 10:22:50"],
  };

  return (
    <div>
      {/* Stats row */}
      <div className="grid grid-cols-4 gap-4 mb-5">
        {[
          { label: "Total conciliaciones", value: "156", sub: "este mes", trend: "+12%" },
          { label: "Monto total", value: "$48.2M", sub: "junio 2025", trend: "+8.4%" },
          { label: "Tasa de éxito", value: "94.2%", sub: "último mes", trend: "+1.1%" },
          { label: "Tiempo promedio", value: "4.2s", sub: "por conciliación", trend: "-0.8s" },
        ].map(({ label, value, sub, trend }) => (
          <div key={label} className="bg-card rounded-xl border border-border px-4 py-4">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-2">{label}</p>
            <div className="flex items-end justify-between">
              <p className="text-[20px] font-bold text-foreground leading-none" style={{ fontFamily: "'DM Mono', monospace" }}>{value}</p>
              <span className="text-[10px] text-emerald-600 font-medium bg-emerald-50 px-1.5 py-0.5 rounded">{trend}</span>
            </div>
            <p className="text-[10px] text-muted-foreground mt-1.5">{sub}</p>
          </div>
        ))}
      </div>

      {/* History table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-border">
          <h2 className="text-[13px] font-semibold text-foreground">Últimas conciliaciones</h2>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-1.5 text-[11px] text-muted-foreground hover:text-foreground px-2.5 py-1.5 rounded-lg border border-border hover:bg-muted/40 transition-colors">
              <Clock size={11} />
              Últimos 30 días
              <ChevronDown size={10} />
            </button>
          </div>
        </div>

        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-muted/30">
              {["ID", "Fecha", "Cliente", "RUT", "Monto", "Cuotas", "Banco", "Estado", ""].map((h) => (
                <th key={h} className="px-4 py-2.5 text-left text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {history.map((rec) => (
              <>
                <tr
                  key={rec.id}
                  className="border-b border-border hover:bg-muted/20 transition-colors cursor-pointer"
                  onClick={() => setExpandedTimeline(expandedTimeline === rec.id ? null : rec.id)}
                >
                  <td className="px-4 py-3 text-[12px] font-medium text-[#2563EB]" style={{ fontFamily: "'DM Mono', monospace" }}>
                    {rec.id}
                  </td>
                  <td className="px-4 py-3 text-[12px] text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                    {fmtDate(rec.date)}
                  </td>
                  <td className="px-4 py-3 text-[12px] font-medium text-foreground">{rec.client}</td>
                  <td className="px-4 py-3 text-[12px] text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                    {rec.rut}
                  </td>
                  <td className="px-4 py-3 text-[12px] font-semibold text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                    {fmt(rec.amount)}
                  </td>
                  <td className="px-4 py-3 text-[12px] text-muted-foreground">{rec.installments}</td>
                  <td className="px-4 py-3 text-[12px] text-muted-foreground">{rec.bank}</td>
                  <td className="px-4 py-3">
                    <RecStatusBadge status={rec.status} />
                  </td>
                  <td className="px-4 py-3">
                    <ChevronDown
                      size={13}
                      className={`text-muted-foreground transition-transform ${expandedTimeline === rec.id ? "rotate-180" : ""}`}
                    />
                  </td>
                </tr>

                {/* Inline timeline */}
                {expandedTimeline === rec.id && (
                  <tr key={`${rec.id}-timeline`} className="border-b border-border bg-muted/10">
                    <td colSpan={9} className="px-8 py-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Clock size={12} className="text-muted-foreground" />
                        <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-widest">
                          Trazabilidad · {rec.id}
                        </p>
                      </div>
                      <div className="flex items-start gap-0">
                        {(timelineSteps[rec.id] ?? []).map((step, i, arr) => (
                          <div key={i} className="flex items-center flex-1 last:flex-none">
                            <div className="flex flex-col items-center">
                              <div className={`w-5 h-5 rounded-full flex items-center justify-center text-white text-[9px] font-bold flex-shrink-0 ${
                                step.toLowerCase().includes("rechazada") || step.toLowerCase().includes("no encontrado")
                                  ? "bg-rose-500"
                                  : step.toLowerCase().includes("parcial")
                                  ? "bg-amber-500"
                                  : "bg-emerald-500"
                              }`}>
                                {i + 1}
                              </div>
                              <p className="text-[10px] text-foreground font-medium mt-2 text-center max-w-[120px] leading-tight">
                                {step.split(" · ")[0]}
                              </p>
                              <p className="text-[9px] text-muted-foreground mt-0.5" style={{ fontFamily: "'DM Mono', monospace" }}>
                                {step.split(" · ")[1]}
                              </p>
                            </div>
                            {i < arr.length - 1 && (
                              <div className={`flex-1 h-px mx-2 mt-[-18px] ${
                                step.toLowerCase().includes("rechazada") || step.toLowerCase().includes("no encontrado")
                                  ? "bg-rose-200"
                                  : "bg-emerald-200"
                              }`} />
                            )}
                          </div>
                        ))}
                      </div>
                    </td>
                  </tr>
                )}
              </>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
